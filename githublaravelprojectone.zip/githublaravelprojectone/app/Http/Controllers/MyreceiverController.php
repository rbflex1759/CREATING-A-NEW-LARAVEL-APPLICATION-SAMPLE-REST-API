<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;


class MyreceiverController extends Controller
{
   
  public function testing(Request $request)
 {
	 $validator= Validator::make($request->all(),[
     
    'memberid' => 'required',
    'name' => 'required ',
    'amount' => 'required',


    ]);
if($validator->fails()){
   return response()->json([
                'status' => 'error',
                'message' => 'Validation Fails',
            ], 401);
}
		
		$memberid = $request->input('memberid');
		$name = $request->input('name');
		$amount = $request->input('amount'); 
		 
$result=array('memberid'=>$memberid,'name'=>$name,'amount'=>$amount);
  return response()->json([
                'status' => 'success',
                'message' => $result,
            ], 401);

	 
 }   
	
	
	
}
